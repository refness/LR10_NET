﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LR10_2
{
    abstract class Appliance
    {
        protected string brand;
        protected int power;

        public abstract void SetSpecs();
        public abstract void Work();
    }

    class WashingMachine : Appliance
    {
        public override void SetSpecs()
        {
            Console.Write("Введіть бренд пральної машини: "); brand = Console.ReadLine();
            Console.Write("Потужність (Вт): "); power = Convert.ToInt32(Console.ReadLine());
        }

        public override void Work() => Console.WriteLine($"{brand} почала цикл прання на {power} Вт.");
    }

    class Fridge : Appliance
    {
        public override void SetSpecs()
        {
            Console.Write("\nВведіть бренд холодильника: "); brand = Console.ReadLine();
            Console.Write("Потужність (Вт): "); power = Convert.ToInt32(Console.ReadLine());
        }

        public override void Work() => Console.WriteLine($"{brand} підтримує холод на потужності {power} Вт.");
    }

    class Program
    {
        static void Main()
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Appliance w = new WashingMachine();
            w.SetSpecs();

            Appliance f = new Fridge();
            f.SetSpecs();

            Console.WriteLine("\nРезультат:");
            w.Work();
            f.Work();
        }
    }
}
