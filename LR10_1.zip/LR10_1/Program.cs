﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LR10_1
{
    abstract class Plane
    {
        protected string model;
        protected double maxSpeed;

        public abstract void Input();
        public abstract void Output();
    }

    class Fighter : Plane
    {
        private int missilesCount;

        public override void Input()
        {
            Console.WriteLine("Введення даних для винищувача");
            Console.Write("Модель: "); model = Console.ReadLine();
            Console.Write("Макс. швидкість (км/год): "); maxSpeed = Convert.ToDouble(Console.ReadLine());
            Console.Write("Кількість ракет: "); missilesCount = Convert.ToInt32(Console.ReadLine());
        }

        public override void Output()
        {
            Console.WriteLine($"\nВинищувач: {model}");
            Console.WriteLine($"Характеристики: {maxSpeed} км/год, озброєння: {missilesCount} ракет.");
        }
    }

    class PassengerLiner : Plane
    {
        private int capacity;

        public override void Input()
        {
            Console.WriteLine("\nВведення даних для лайнера");
            Console.Write("Модель: "); model = Console.ReadLine();
            Console.Write("Макс. швидкість (км/год): "); maxSpeed = Convert.ToDouble(Console.ReadLine());
            Console.Write("Кількість пасажирів: "); capacity = Convert.ToInt32(Console.ReadLine());
        }

        public override void Output()
        {
            Console.WriteLine($"\nПасажирський лайнер: {model}");
            Console.WriteLine($"Характеристики: {maxSpeed} км/год, місткість: {capacity} чол.");
        }
    }

    class Program
    {
        static void Main()
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Plane f = new Fighter();
            f.Input();

            Plane p = new PassengerLiner();
            p.Input();

            Console.WriteLine("\nРезультати:");
            f.Output();
            p.Output();

            Console.ReadKey();
        }
    }
}
